**Open Files - Next**

This plugin shows any open files on the array that might prevent a clean shutdown.  The plugin web page is installed in 'Tools'.  You can stop all array and troubleshoot shutdown problems from open files.  After you stop all array processes, you will see what processes are still holding files open on the array preventing a shutdown.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.